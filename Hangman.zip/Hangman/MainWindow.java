package hangman;

import javax.swing.*;
import java.awt.*;

public class MainWindow extends JFrame {
    private HealthPanel healthPanel;
    private WordLoader wordLoader;
    private WordPanel wordPanel;
    private ButtonPanel buttonPanel;

    private static final int MAX_LIVES = 6;

    public MainWindow() {
        setTitle("Hangman");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        healthPanel = new HealthPanel(MAX_LIVES);
        add(healthPanel, BorderLayout.NORTH);

        wordLoader = new WordLoader("wordlist.txt");
        String randomWord = wordLoader.getRandomWord();
        wordPanel = new WordPanel(randomWord);
        add(wordPanel, BorderLayout.CENTER);

        buttonPanel = new ButtonPanel(wordPanel);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    public void handleIncorrectGuess() {
        healthPanel.removeLife();

        if (healthPanel.getCurrentHealth() <= 0) {
            gameOver();
        }
    }

    public void handleGameWon() {
        JOptionPane.showMessageDialog(this, "Congratulations! You guessed the word correctly! Hangman completed!", "Victory", JOptionPane.INFORMATION_MESSAGE);
        buttonPanel.resetButtons(); // Reset button visibility
        promptPlayAgain();
    }



    private void gameOver() {
        JOptionPane.showMessageDialog(this, "Sorry, you ran out of lives. The word was: " + wordPanel.getWord(), "Game Over", JOptionPane.ERROR_MESSAGE);
        promptPlayAgain();
    }

    private void promptPlayAgain() {
        int option = JOptionPane.showConfirmDialog(this, "Do you want to play again?", "Play Again", JOptionPane.YES_NO_OPTION);
        if (option == JOptionPane.YES_OPTION) {
            // Reset the game
            resetGame();
        } else {
            System.exit(0);
        }
    }

    private void resetGame() {
        // Reset the word panel with a new random word
        String randomWord = wordLoader.getRandomWord();
        wordPanel = new WordPanel(randomWord);

        // Reset the health panel to its initial state
        healthPanel = new HealthPanel(MAX_LIVES);

        // Reset the button panel to its initial state
        buttonPanel.resetButtons();

        // Remove all components from the content pane and add the reinitialized panels
        getContentPane().removeAll();
        add(healthPanel, BorderLayout.NORTH);
        add(wordPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        // Refresh the window to reflect changes
        revalidate();
        repaint();
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(MainWindow::new);
    }
}
