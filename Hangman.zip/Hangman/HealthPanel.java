package hangman;

import javax.swing.*;
import java.awt.*;

public class HealthPanel extends JPanel{
	private JLabel[] healthLabels;
	private int maxHealth;
	private int currentHealth; 
	
	public HealthPanel(int maxLives) {
		maxHealth = 7;
		currentHealth = maxHealth;
		setLayout(new FlowLayout());
		healthLabels = new JLabel[maxHealth];
		
		for(int i=0; i<maxHealth; i++) {
			healthLabels[i]= new JLabel("❤");
			healthLabels[i].setForeground(Color.GREEN);
			add(healthLabels[i]);
		}	
	}
	public void removeLife() {
		if (currentHealth>0) {
			healthLabels[currentHealth-1].setForeground(Color.RED);
			currentHealth= currentHealth - 1;
		}
	}
	
	public int getCurrentHealth() {
		return currentHealth;
	}
	
	public int getMaxHealth() {
		return maxHealth;
	}

}
