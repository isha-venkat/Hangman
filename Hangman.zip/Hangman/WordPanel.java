package hangman;

import javax.swing.*;
import java.awt.*;

public class WordPanel extends JPanel {
	private JLabel wordLabel;
	private String word;

	public WordPanel(String targetWord) {
		setLayout(new FlowLayout());

		this.word = targetWord;
		wordLabel = new JLabel(maskWord(targetWord));
		add(wordLabel);
	}

	String maskWord(String word) {
		StringBuilder maskedWord = new StringBuilder();
		for (int i = 0; i < word.length(); i++) {
			maskedWord.append("_ ");
		}

		return maskedWord.toString();
	}

	public boolean guess(String letter) {
		boolean guessedCorrectly = false;
		StringBuilder updatedWord = new StringBuilder(wordLabel.getText());

		// Check if the guessed letter is present in the word
		for (int i = 0; i < word.length(); i++) {
			if (Character.toLowerCase(letter.charAt(0)) == Character.toLowerCase(word.charAt(i))) {
				updatedWord.setCharAt(i * 2, word.charAt(i));
				guessedCorrectly = true;
			}
		}

		wordLabel.setText(updatedWord.toString());
		return guessedCorrectly;
	}

	public boolean isWordGuessed() {
		return !wordLabel.getText().contains("_");
	}

	public String getWord() {
		return word;
	}
}
