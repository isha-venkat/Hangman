package hangman;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ButtonPanel extends JPanel {
    private WordPanel wordPanel;
    private JButton[] letterButtons;

    public ButtonPanel(WordPanel wordPanel) {
        this.wordPanel = wordPanel;

        setLayout(new GridLayout(3, 9));
        letterButtons = new JButton[26];

        for (char c = 'A'; c <= 'Z'; c++) {
            final char letter = c;

            JButton button = new JButton(String.valueOf(c));
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    guessLetter(letter, (JButton) e.getSource());
                }
            });

            letterButtons[c - 'A'] = button;
            add(button);
        }

    }

    public void resetButtons() {
        for (JButton button : letterButtons) {
            button.setVisible(true);
        }
    }


    private void guessLetter(char letter, JButton button) {
        boolean guessedCorrectly = wordPanel.guess(String.valueOf(letter));
        if (guessedCorrectly && wordPanel.isWordGuessed()) { // Check if the word is completely guessed
            ((MainWindow) SwingUtilities.getWindowAncestor(this)).handleGameWon();
        } else if (!guessedCorrectly) {
            ((MainWindow) SwingUtilities.getWindowAncestor(this)).handleIncorrectGuess();
        }
        button.setVisible(false); // Make the button invisible after it has been clicked
    }




}
