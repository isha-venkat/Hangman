package hangman;
import javax.swing.*;
import java.awt.*;
import java.util.Random;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class WordLoader {
	private List<String> wordList;
	
	private void loadWords(String filename) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                wordList.add(line.trim());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
	
	public WordLoader(String filename) {
		wordList = new ArrayList<>();
		loadWords(filename);
	}
	
	public String getRandomWord() {
        if (!wordList.isEmpty()) {
            Random random = new Random();
            int index = random.nextInt(wordList.size());
            return wordList.get(index);
        } else {
            return null;
        }
    }

}
